﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH08_Evelin_Alim_Natadjaja
{
    public partial class UNIQME : Form
    {
        DataTable dtCart;
        OpenFileDialog ofd_Others = new OpenFileDialog();
        int indexRow;
        bool checkAdded;
        int subtotal = 0;
        double total;

        public UNIQME()
        {
            InitializeComponent();
        }

        private void UNIQME_Load(object sender, EventArgs e)
        {
            dtCart = new DataTable();
            dtCart.Columns.Add("Item Name");
            dtCart.Columns.Add("Quantity");
            dtCart.Columns.Add("Price");
            dtCart.Columns.Add("Total");
            dGV_Cart.DataSource = dtCart;
            dGV_Cart.Columns[0].Width = 70;
            dGV_Cart.Columns[1].Width = 35;
            dGV_Cart.Columns[2].Width = 50;
            dGV_Cart.Columns[3].Width = 80;
            tB_Subtotal.Text = "Rp 0,-";
            tB_Total.Text = "Rp 0,-";
        }

        public int CheckQuantity(string itemName)
        {
            checkAdded = false;
            int quantity = 1;
            for (int i = 0; i < dtCart.Rows.Count; i++)
            {
                if (itemName == dtCart.Rows[i][0].ToString())
                {
                    checkAdded = true;
                    quantity = Convert.ToInt32(dtCart.Rows[i][1]);
                    indexRow = i;
                    dtCart.Rows.RemoveAt(i);
                    quantity++;
                }
            }
            return quantity;
        }

        public void AddToCart(string itemName, string itemRupiah)
        {
            int itemPrice = int.Parse(Regex.Replace(itemRupiah, @",.*|\D", ""));
            int quantity = CheckQuantity(itemName);
            string totalRupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", itemPrice * quantity);
            if (checkAdded)
            {
                DataRow row = dtCart.NewRow();
                row[0] = itemName;
                row[1] = quantity;
                row[2] = itemRupiah;
                row[3] = totalRupiah;
                dtCart.Rows.InsertAt(row, indexRow);
            }
            else
            {
                dtCart.Rows.Add(itemName, quantity, itemRupiah, totalRupiah);
            }
            CountTotal(itemPrice);
            dGV_Cart.CurrentCell = null;
        }

        public void CountTotal(int itemPrice)
        {
            total = 0;
            subtotal += itemPrice;
            total = subtotal + (subtotal * 0.1);
            tB_Subtotal.Text = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", subtotal);
            tB_Total.Text = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", total);
        }

        private void btn_AddItemA_Click(object sender, EventArgs e)
        {
            AddToCart(lb_ItemA.Text, lb_HargaItemA.Text);
        }

        private void btn_AddItemB_Click(object sender, EventArgs e)
        {
            AddToCart(lb_ItemB.Text, lb_HargaItemB.Text);
        }

        private void btn_AddItemC_Click(object sender, EventArgs e)
        {
            AddToCart(lb_ItemC.Text, lb_HargaItemC.Text);
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false;
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.T_Shirt_Basic_Black;
            pBox_ItemB.Image = Properties.Resources.Floral_T_Shirt;
            pBox_ItemC.Image = Properties.Resources.Sport_T_Shirt;
            lb_ItemA.Text = "T-Shirt Basic Black";
            lb_ItemB.Text = "Floral T-Shirt";
            lb_ItemC.Text = "Sport T-Shirt";
            lb_HargaItemA.Text = "Rp 50.000,-";
            lb_HargaItemB.Text = "Rp 85.000,-";
            lb_HargaItemC.Text = "Rp 105.000,-";
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false;
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.Checkered_Shirt;
            pBox_ItemB.Image = Properties.Resources.Long_Sleeve_Shirt;
            pBox_ItemC.Image = Properties.Resources.Short_Sleeve_Shirt;
            lb_ItemA.Text = "Checkered Shirt";
            lb_ItemB.Text = "Long Sleeve Shirt";
            lb_ItemC.Text = "Short Sleeve Shirt";
            lb_HargaItemA.Text = "Rp 150.000,-";
            lb_HargaItemB.Text = "Rp 175.000,-";
            lb_HargaItemC.Text = "Rp 210.000,-";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false;
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.Cargo_Short_Pants;
            pBox_ItemB.Image = Properties.Resources.Relaxed_Short_Pants;
            pBox_ItemC.Image = Properties.Resources.Denim_Shorts;
            lb_ItemA.Text = "Cargo Short Pants";
            lb_ItemB.Text = "Relaxed Short Pants";
            lb_ItemC.Text = "Denim Shorts";
            lb_HargaItemA.Text = "Rp 200.000,-";
            lb_HargaItemB.Text = "Rp 145.000,-";
            lb_HargaItemC.Text = "Rp 130.000,-";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false; 
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.Black_Suit_Pants;
            pBox_ItemB.Image = Properties.Resources.Blue_Jeans;
            pBox_ItemC.Image = Properties.Resources.Jogger_Pants;
            lb_ItemA.Text = "Black Suit Pants";
            lb_ItemB.Text = "Blue Jeans";
            lb_ItemC.Text = "Jogger Pants";
            lb_HargaItemA.Text = "Rp 250.000,-";
            lb_HargaItemB.Text = "Rp 215.000,-";
            lb_HargaItemC.Text = "Rp 155.000,-";
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false;
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.Leather_Formal_Shoes;
            pBox_ItemB.Image = Properties.Resources.Pink_Running_Shoes;
            pBox_ItemC.Image = Properties.Resources.White_Sneakers;
            lb_ItemA.Text = "Leather Formal Shoes";
            lb_ItemB.Text = "Pink Running Shoes";
            lb_ItemC.Text = "White Sneakers";
            lb_HargaItemA.Text = "Rp 500.000,-";
            lb_HargaItemB.Text = "Rp 325.000,-";
            lb_HargaItemC.Text = "Rp 460.000,-";
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Others.Visible = false;
            panel_Item.Visible = true;
            pBox_ItemA.Image = Properties.Resources.Clover_Heart_Necklace;
            pBox_ItemB.Image = Properties.Resources.Leafy_Diamond_Bracelet;
            pBox_ItemC.Image = Properties.Resources.Round_Bezel_Earrings;
            lb_ItemA.Text = "Clover Heart Necklace";
            lb_ItemB.Text = "Leafy Diamond Bracelet";
            lb_ItemC.Text = "Round Bezel Earrings";
            lb_HargaItemA.Text = "Rp 370.000,-";
            lb_HargaItemB.Text = "Rp 235.000,-";
            lb_HargaItemC.Text = "Rp 220.000,-";
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Item.Visible = false;
            panel_Others.Visible = true;
            tB_ItemName.Text = string.Empty;
            tB_ItemPrice.Text = string.Empty;
            tB_ItemName.Enabled = false;
            tB_ItemPrice.Enabled = false;
            btn_AddOthers.Enabled = false;
            pBox_Others.Image = null;
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            ofd_Others.Filter = "Image Files (*.gif;*.jpg;*.jpeg;*.bmp;*.wmf;*.png)|*.gif;*.jpg;*.jpeg;*.bmp;*.wmf;*.png";
            if (ofd_Others.ShowDialog() == DialogResult.OK)
            {
                pBox_Others.Image = new Bitmap(ofd_Others.FileName);
                tB_ItemName.Enabled = true;
                tB_ItemPrice.Enabled = true;
            }
        }

        private void tB_ItemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tB_ItemName_TextChanged(object sender, EventArgs e)
        {
            if (tB_ItemName.Text == string.Empty || tB_ItemPrice.Text == string.Empty)
            {
                btn_AddOthers.Enabled = false;
            }
            else
            {
                btn_AddOthers.Enabled = true;
            }
        }

        private void tB_ItemPrice_TextChanged(object sender, EventArgs e)
        {
            if (tB_ItemPrice.Text == string.Empty || tB_ItemName.Text == string.Empty)
            {
                btn_AddOthers.Enabled = false;
            }
            else
            {
                btn_AddOthers.Enabled = true;
            }
        }

        public void AddOthers(string itemName, int itemPrice)
        {
            int quantity = CheckQuantity(itemName);
            string itemRupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", itemPrice);
            string totalRupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", itemPrice * quantity);
            if (checkAdded)
            {
                DataRow row = dtCart.NewRow();
                row[0] = itemName;
                row[1] = quantity;
                row[2] = itemRupiah;
                row[3] = totalRupiah;
                dtCart.Rows.InsertAt(row, indexRow);
            }
            else
            {
                dtCart.Rows.Add(itemName, quantity, itemRupiah, totalRupiah);
            }
            CountTotal(itemPrice);
            dGV_Cart.CurrentCell = null;
        }

        private void btn_AddOthers_Click(object sender, EventArgs e)
        {
            AddOthers(tB_ItemName.Text, Convert.ToInt32(tB_ItemPrice.Text));
            tB_ItemName.Text = string.Empty;
            tB_ItemPrice.Text = string.Empty;
            tB_ItemName.Enabled = false;
            tB_ItemPrice.Enabled = false;
            btn_AddOthers.Enabled = false;
            dGV_Cart.CurrentCell = null;
            pBox_Others.Image = null;
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dGV_Cart.CurrentCell != null)
            {
                DataGridViewRow dgvr = dGV_Cart.CurrentRow;
                int priceDeleted = int.Parse(Regex.Replace(dgvr.Cells[3].Value.ToString(), @",.*|\D", ""));
                subtotal -= priceDeleted;
                total = subtotal + (subtotal * 0.1);
                dGV_Cart.Rows.Remove(dgvr);
                tB_Subtotal.Text = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", subtotal);
                tB_Total.Text = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "Rp {0:N0},-", total);
                dGV_Cart.CurrentCell = null;
            }
        }
    }
}
