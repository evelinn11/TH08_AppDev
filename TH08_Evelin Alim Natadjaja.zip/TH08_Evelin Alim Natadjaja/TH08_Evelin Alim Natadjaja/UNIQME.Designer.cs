﻿namespace TH08_Evelin_Alim_Natadjaja
{
    partial class UNIQME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip_Uniqme = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dGV_Cart = new System.Windows.Forms.DataGridView();
            this.lb_Subtotal = new System.Windows.Forms.Label();
            this.lb_Total = new System.Windows.Forms.Label();
            this.tB_Subtotal = new System.Windows.Forms.TextBox();
            this.tB_Total = new System.Windows.Forms.TextBox();
            this.panel_Item = new System.Windows.Forms.Panel();
            this.btn_AddItemC = new System.Windows.Forms.Button();
            this.btn_AddItemB = new System.Windows.Forms.Button();
            this.btn_AddItemA = new System.Windows.Forms.Button();
            this.lb_HargaItemC = new System.Windows.Forms.Label();
            this.lb_HargaItemB = new System.Windows.Forms.Label();
            this.lb_HargaItemA = new System.Windows.Forms.Label();
            this.lb_ItemC = new System.Windows.Forms.Label();
            this.lb_ItemB = new System.Windows.Forms.Label();
            this.lb_ItemA = new System.Windows.Forms.Label();
            this.pBox_ItemC = new System.Windows.Forms.PictureBox();
            this.pBox_ItemB = new System.Windows.Forms.PictureBox();
            this.pBox_ItemA = new System.Windows.Forms.PictureBox();
            this.panel_Others = new System.Windows.Forms.Panel();
            this.pBox_Others = new System.Windows.Forms.PictureBox();
            this.btn_AddOthers = new System.Windows.Forms.Button();
            this.tB_ItemPrice = new System.Windows.Forms.TextBox();
            this.tB_ItemName = new System.Windows.Forms.TextBox();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.lb_ItemName = new System.Windows.Forms.Label();
            this.lb_ItemPrice = new System.Windows.Forms.Label();
            this.lb_UploadImage = new System.Windows.Forms.Label();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.menuStrip_Uniqme.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Cart)).BeginInit();
            this.panel_Item.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemA)).BeginInit();
            this.panel_Others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Others)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip_Uniqme
            // 
            this.menuStrip_Uniqme.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accesoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip_Uniqme.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Uniqme.Name = "menuStrip_Uniqme";
            this.menuStrip_Uniqme.Size = new System.Drawing.Size(800, 24);
            this.menuStrip_Uniqme.TabIndex = 0;
            this.menuStrip_Uniqme.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accesoriesToolStripMenuItem
            // 
            this.accesoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accesoriesToolStripMenuItem.Name = "accesoriesToolStripMenuItem";
            this.accesoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accesoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dGV_Cart
            // 
            this.dGV_Cart.AllowUserToAddRows = false;
            this.dGV_Cart.AllowUserToDeleteRows = false;
            this.dGV_Cart.AllowUserToResizeColumns = false;
            this.dGV_Cart.AllowUserToResizeRows = false;
            this.dGV_Cart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_Cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_Cart.Location = new System.Drawing.Point(470, 27);
            this.dGV_Cart.MultiSelect = false;
            this.dGV_Cart.Name = "dGV_Cart";
            this.dGV_Cart.ReadOnly = true;
            this.dGV_Cart.RowHeadersVisible = false;
            this.dGV_Cart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_Cart.Size = new System.Drawing.Size(316, 255);
            this.dGV_Cart.TabIndex = 1;
            // 
            // lb_Subtotal
            // 
            this.lb_Subtotal.AutoSize = true;
            this.lb_Subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Subtotal.Location = new System.Drawing.Point(467, 328);
            this.lb_Subtotal.Name = "lb_Subtotal";
            this.lb_Subtotal.Size = new System.Drawing.Size(106, 24);
            this.lb_Subtotal.TabIndex = 2;
            this.lb_Subtotal.Text = "Sub-Total:";
            // 
            // lb_Total
            // 
            this.lb_Total.AutoSize = true;
            this.lb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total.Location = new System.Drawing.Point(511, 363);
            this.lb_Total.Name = "lb_Total";
            this.lb_Total.Size = new System.Drawing.Size(62, 24);
            this.lb_Total.TabIndex = 3;
            this.lb_Total.Text = "Total:";
            // 
            // tB_Subtotal
            // 
            this.tB_Subtotal.Location = new System.Drawing.Point(579, 332);
            this.tB_Subtotal.Name = "tB_Subtotal";
            this.tB_Subtotal.Size = new System.Drawing.Size(150, 20);
            this.tB_Subtotal.TabIndex = 4;
            // 
            // tB_Total
            // 
            this.tB_Total.Location = new System.Drawing.Point(579, 367);
            this.tB_Total.Name = "tB_Total";
            this.tB_Total.Size = new System.Drawing.Size(150, 20);
            this.tB_Total.TabIndex = 5;
            // 
            // panel_Item
            // 
            this.panel_Item.Controls.Add(this.btn_AddItemC);
            this.panel_Item.Controls.Add(this.btn_AddItemB);
            this.panel_Item.Controls.Add(this.btn_AddItemA);
            this.panel_Item.Controls.Add(this.lb_HargaItemC);
            this.panel_Item.Controls.Add(this.lb_HargaItemB);
            this.panel_Item.Controls.Add(this.lb_HargaItemA);
            this.panel_Item.Controls.Add(this.lb_ItemC);
            this.panel_Item.Controls.Add(this.lb_ItemB);
            this.panel_Item.Controls.Add(this.lb_ItemA);
            this.panel_Item.Controls.Add(this.pBox_ItemC);
            this.panel_Item.Controls.Add(this.pBox_ItemB);
            this.panel_Item.Controls.Add(this.pBox_ItemA);
            this.panel_Item.Location = new System.Drawing.Point(12, 27);
            this.panel_Item.Name = "panel_Item";
            this.panel_Item.Size = new System.Drawing.Size(426, 303);
            this.panel_Item.TabIndex = 6;
            this.panel_Item.Visible = false;
            // 
            // btn_AddItemC
            // 
            this.btn_AddItemC.Location = new System.Drawing.Point(303, 252);
            this.btn_AddItemC.Name = "btn_AddItemC";
            this.btn_AddItemC.Size = new System.Drawing.Size(82, 23);
            this.btn_AddItemC.TabIndex = 11;
            this.btn_AddItemC.Text = "Add To Cart";
            this.btn_AddItemC.UseVisualStyleBackColor = true;
            this.btn_AddItemC.Click += new System.EventHandler(this.btn_AddItemC_Click);
            // 
            // btn_AddItemB
            // 
            this.btn_AddItemB.Location = new System.Drawing.Point(158, 252);
            this.btn_AddItemB.Name = "btn_AddItemB";
            this.btn_AddItemB.Size = new System.Drawing.Size(82, 23);
            this.btn_AddItemB.TabIndex = 10;
            this.btn_AddItemB.Text = "Add To Cart";
            this.btn_AddItemB.UseVisualStyleBackColor = true;
            this.btn_AddItemB.Click += new System.EventHandler(this.btn_AddItemB_Click);
            // 
            // btn_AddItemA
            // 
            this.btn_AddItemA.Location = new System.Drawing.Point(12, 252);
            this.btn_AddItemA.Name = "btn_AddItemA";
            this.btn_AddItemA.Size = new System.Drawing.Size(82, 23);
            this.btn_AddItemA.TabIndex = 9;
            this.btn_AddItemA.Text = "Add To Cart";
            this.btn_AddItemA.UseVisualStyleBackColor = true;
            this.btn_AddItemA.Click += new System.EventHandler(this.btn_AddItemA_Click);
            // 
            // lb_HargaItemC
            // 
            this.lb_HargaItemC.AutoSize = true;
            this.lb_HargaItemC.Location = new System.Drawing.Point(309, 226);
            this.lb_HargaItemC.Name = "lb_HargaItemC";
            this.lb_HargaItemC.Size = new System.Drawing.Size(69, 13);
            this.lb_HargaItemC.TabIndex = 8;
            this.lb_HargaItemC.Text = "Rp 105.000,-";
            // 
            // lb_HargaItemB
            // 
            this.lb_HargaItemB.AutoSize = true;
            this.lb_HargaItemB.Location = new System.Drawing.Point(165, 226);
            this.lb_HargaItemB.Name = "lb_HargaItemB";
            this.lb_HargaItemB.Size = new System.Drawing.Size(63, 13);
            this.lb_HargaItemB.TabIndex = 7;
            this.lb_HargaItemB.Text = "Rp 85.000,-";
            // 
            // lb_HargaItemA
            // 
            this.lb_HargaItemA.AutoSize = true;
            this.lb_HargaItemA.Location = new System.Drawing.Point(20, 226);
            this.lb_HargaItemA.Name = "lb_HargaItemA";
            this.lb_HargaItemA.Size = new System.Drawing.Size(63, 13);
            this.lb_HargaItemA.TabIndex = 6;
            this.lb_HargaItemA.Text = "Rp 50.000,-";
            // 
            // lb_ItemC
            // 
            this.lb_ItemC.AutoSize = true;
            this.lb_ItemC.Location = new System.Drawing.Point(309, 203);
            this.lb_ItemC.Name = "lb_ItemC";
            this.lb_ItemC.Size = new System.Drawing.Size(66, 13);
            this.lb_ItemC.TabIndex = 5;
            this.lb_ItemC.Text = "Sport T-Shirt";
            // 
            // lb_ItemB
            // 
            this.lb_ItemB.AutoSize = true;
            this.lb_ItemB.Location = new System.Drawing.Point(165, 203);
            this.lb_ItemB.Name = "lb_ItemB";
            this.lb_ItemB.Size = new System.Drawing.Size(66, 13);
            this.lb_ItemB.TabIndex = 4;
            this.lb_ItemB.Text = "Floral T-Shirt";
            // 
            // lb_ItemA
            // 
            this.lb_ItemA.AutoSize = true;
            this.lb_ItemA.Location = new System.Drawing.Point(20, 203);
            this.lb_ItemA.Name = "lb_ItemA";
            this.lb_ItemA.Size = new System.Drawing.Size(97, 13);
            this.lb_ItemA.TabIndex = 3;
            this.lb_ItemA.Text = "T-Shirt Basic Black";
            // 
            // pBox_ItemC
            // 
            this.pBox_ItemC.BackColor = System.Drawing.Color.White;
            this.pBox_ItemC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBox_ItemC.Image = global::TH08_Evelin_Alim_Natadjaja.Properties.Resources.Sport_T_Shirt;
            this.pBox_ItemC.Location = new System.Drawing.Point(303, 18);
            this.pBox_ItemC.Name = "pBox_ItemC";
            this.pBox_ItemC.Size = new System.Drawing.Size(108, 171);
            this.pBox_ItemC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_ItemC.TabIndex = 2;
            this.pBox_ItemC.TabStop = false;
            // 
            // pBox_ItemB
            // 
            this.pBox_ItemB.BackColor = System.Drawing.Color.White;
            this.pBox_ItemB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBox_ItemB.Image = global::TH08_Evelin_Alim_Natadjaja.Properties.Resources.Floral_T_Shirt;
            this.pBox_ItemB.Location = new System.Drawing.Point(158, 18);
            this.pBox_ItemB.Name = "pBox_ItemB";
            this.pBox_ItemB.Size = new System.Drawing.Size(108, 171);
            this.pBox_ItemB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_ItemB.TabIndex = 1;
            this.pBox_ItemB.TabStop = false;
            // 
            // pBox_ItemA
            // 
            this.pBox_ItemA.BackColor = System.Drawing.Color.White;
            this.pBox_ItemA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBox_ItemA.Image = global::TH08_Evelin_Alim_Natadjaja.Properties.Resources.T_Shirt_Basic_Black;
            this.pBox_ItemA.Location = new System.Drawing.Point(12, 18);
            this.pBox_ItemA.Name = "pBox_ItemA";
            this.pBox_ItemA.Size = new System.Drawing.Size(108, 171);
            this.pBox_ItemA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_ItemA.TabIndex = 0;
            this.pBox_ItemA.TabStop = false;
            // 
            // panel_Others
            // 
            this.panel_Others.Controls.Add(this.pBox_Others);
            this.panel_Others.Controls.Add(this.btn_AddOthers);
            this.panel_Others.Controls.Add(this.tB_ItemPrice);
            this.panel_Others.Controls.Add(this.tB_ItemName);
            this.panel_Others.Controls.Add(this.btn_Upload);
            this.panel_Others.Controls.Add(this.lb_ItemName);
            this.panel_Others.Controls.Add(this.lb_ItemPrice);
            this.panel_Others.Controls.Add(this.lb_UploadImage);
            this.panel_Others.Location = new System.Drawing.Point(0, 30);
            this.panel_Others.Name = "panel_Others";
            this.panel_Others.Size = new System.Drawing.Size(444, 322);
            this.panel_Others.TabIndex = 7;
            this.panel_Others.Visible = false;
            // 
            // pBox_Others
            // 
            this.pBox_Others.BackColor = System.Drawing.Color.White;
            this.pBox_Others.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBox_Others.Location = new System.Drawing.Point(95, 60);
            this.pBox_Others.Name = "pBox_Others";
            this.pBox_Others.Size = new System.Drawing.Size(107, 169);
            this.pBox_Others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_Others.TabIndex = 13;
            this.pBox_Others.TabStop = false;
            // 
            // btn_AddOthers
            // 
            this.btn_AddOthers.Enabled = false;
            this.btn_AddOthers.Location = new System.Drawing.Point(216, 205);
            this.btn_AddOthers.Name = "btn_AddOthers";
            this.btn_AddOthers.Size = new System.Drawing.Size(100, 23);
            this.btn_AddOthers.TabIndex = 7;
            this.btn_AddOthers.Text = "Add To Cart";
            this.btn_AddOthers.UseVisualStyleBackColor = true;
            this.btn_AddOthers.Click += new System.EventHandler(this.btn_AddOthers_Click);
            // 
            // tB_ItemPrice
            // 
            this.tB_ItemPrice.Enabled = false;
            this.tB_ItemPrice.Location = new System.Drawing.Point(216, 126);
            this.tB_ItemPrice.Name = "tB_ItemPrice";
            this.tB_ItemPrice.Size = new System.Drawing.Size(94, 20);
            this.tB_ItemPrice.TabIndex = 6;
            this.tB_ItemPrice.TextChanged += new System.EventHandler(this.tB_ItemPrice_TextChanged);
            this.tB_ItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tB_ItemPrice_KeyPress);
            // 
            // tB_ItemName
            // 
            this.tB_ItemName.Enabled = false;
            this.tB_ItemName.Location = new System.Drawing.Point(216, 74);
            this.tB_ItemName.Name = "tB_ItemName";
            this.tB_ItemName.Size = new System.Drawing.Size(94, 20);
            this.tB_ItemName.TabIndex = 4;
            this.tB_ItemName.TextChanged += new System.EventHandler(this.tB_ItemName_TextChanged);
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(178, 15);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(100, 23);
            this.btn_Upload.TabIndex = 3;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // lb_ItemName
            // 
            this.lb_ItemName.AutoSize = true;
            this.lb_ItemName.Location = new System.Drawing.Point(213, 58);
            this.lb_ItemName.Name = "lb_ItemName";
            this.lb_ItemName.Size = new System.Drawing.Size(61, 13);
            this.lb_ItemName.TabIndex = 2;
            this.lb_ItemName.Text = "Item Name:";
            // 
            // lb_ItemPrice
            // 
            this.lb_ItemPrice.AutoSize = true;
            this.lb_ItemPrice.Location = new System.Drawing.Point(213, 110);
            this.lb_ItemPrice.Name = "lb_ItemPrice";
            this.lb_ItemPrice.Size = new System.Drawing.Size(57, 13);
            this.lb_ItemPrice.TabIndex = 1;
            this.lb_ItemPrice.Text = "Item Price:";
            // 
            // lb_UploadImage
            // 
            this.lb_UploadImage.AutoSize = true;
            this.lb_UploadImage.Location = new System.Drawing.Point(92, 20);
            this.lb_UploadImage.Name = "lb_UploadImage";
            this.lb_UploadImage.Size = new System.Drawing.Size(73, 13);
            this.lb_UploadImage.TabIndex = 0;
            this.lb_UploadImage.Text = "Upload Image";
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(470, 288);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(64, 27);
            this.btn_Delete.TabIndex = 8;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // UNIQME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.panel_Others);
            this.Controls.Add(this.panel_Item);
            this.Controls.Add(this.tB_Total);
            this.Controls.Add(this.tB_Subtotal);
            this.Controls.Add(this.lb_Total);
            this.Controls.Add(this.lb_Subtotal);
            this.Controls.Add(this.dGV_Cart);
            this.Controls.Add(this.menuStrip_Uniqme);
            this.MainMenuStrip = this.menuStrip_Uniqme;
            this.Name = "UNIQME";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.UNIQME_Load);
            this.menuStrip_Uniqme.ResumeLayout(false);
            this.menuStrip_Uniqme.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Cart)).EndInit();
            this.panel_Item.ResumeLayout(false);
            this.panel_Item.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_ItemA)).EndInit();
            this.panel_Others.ResumeLayout(false);
            this.panel_Others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip_Uniqme;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accesoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dGV_Cart;
        private System.Windows.Forms.Label lb_Subtotal;
        private System.Windows.Forms.Label lb_Total;
        private System.Windows.Forms.TextBox tB_Subtotal;
        private System.Windows.Forms.TextBox tB_Total;
        private System.Windows.Forms.Panel panel_Item;
        private System.Windows.Forms.PictureBox pBox_ItemC;
        private System.Windows.Forms.PictureBox pBox_ItemB;
        private System.Windows.Forms.PictureBox pBox_ItemA;
        private System.Windows.Forms.Button btn_AddItemC;
        private System.Windows.Forms.Button btn_AddItemB;
        private System.Windows.Forms.Button btn_AddItemA;
        private System.Windows.Forms.Label lb_HargaItemC;
        private System.Windows.Forms.Label lb_HargaItemB;
        private System.Windows.Forms.Label lb_HargaItemA;
        private System.Windows.Forms.Label lb_ItemC;
        private System.Windows.Forms.Label lb_ItemB;
        private System.Windows.Forms.Label lb_ItemA;
        private System.Windows.Forms.Panel panel_Others;
        private System.Windows.Forms.Label lb_ItemName;
        private System.Windows.Forms.Label lb_ItemPrice;
        private System.Windows.Forms.Label lb_UploadImage;
        private System.Windows.Forms.PictureBox pBox_Others;
        private System.Windows.Forms.Button btn_AddOthers;
        private System.Windows.Forms.TextBox tB_ItemPrice;
        private System.Windows.Forms.TextBox tB_ItemName;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.Button btn_Delete;
    }
}

